const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const { Pool } = require('pg');
const multer = require('multer');
const { PDFParser } = require('pdf-parse');
const { AIModel } = require('@google/generativeai').AI;

// Load environment variables
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Configure multer for file upload
const upload = multer({
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed!'));
    }
  },
});

// Initialize PostgreSQL pool
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// Initialize Google AI Model
const model = new AIModel(process.env.GOOGLE_API_KEY);

// Middleware to parse PDF files
const parsePDF = async (pdfBuffer) => {
  const parser = new PDFParser();
  return await parser.parseBuffer(pdfBuffer);
};

// Analyze resume using AI
const analyzeResume = async (text) => {
  const prompt = `
    You are an expert technical recruiter and career coach. Analyze the following resume text and extract the information into a valid JSON object. The JSON object must conform to the following structure, and all fields must be populated. Do not include any text or markdown formatting before or after the JSON object.

    Resume Text:
    """
    ${text}
    """

    JSON Structure:
    {
      "personal_details": {
        "name": "string | null",
        "email": "string | null",
        "phone": "string | null",
        "linkedin_url": "string | null",
        "portfolio_url": "string | null"
      },
      "resume_content": {
        "summary": "string | null",
        "work_experience": [{ "role": "string", "company": "string", "duration": "string", "description": ["string"] }],
        "education": [{ "degree": "string", "institution": "string", "graduation_year": "string" }],
        "projects": [{ "title": "string", "description": "string", "technologies": ["string"] }],
        "certifications": [{ "name": "string", "issuing_organization": "string", "year": "string" }]
      },
      "skills": {
        "technical_skills": ["string"],
        "soft_skills": ["string"]
      },
      "feedback": {
        "resume_rating": "number (1-10)",
        "improvement_areas": ["string"],
        "upskill_suggestions": ["string"]
      }
    }
  `;

  try {
    const result = await model.generateContent(prompt);
    return JSON.parse(result.text());
  } catch (error) {
    console.error('Error in AI analysis:', error);
    throw new Error('Failed to analyze resume content');
  }
};

// Routes
app.post('/api/resume/analyze', upload.single('resume'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const pdfBuffer = req.file.buffer;
    const pdfText = await parsePDF(pdfBuffer);
    
    const analysis = await analyzeResume(pdfText.text);
    
    const result = await pool.query(
      'INSERT INTO resumes (file_name, uploaded_at, personal_details, resume_content, skills, feedback) VALUES ($1, CURRENT_TIMESTAMP, $2, $3, $4, $5) RETURNING id',
      [
        req.file.originalname,
        JSON.stringify(analysis.personal_details),
        JSON.stringify(analysis.resume_content),
        JSON.stringify(analysis.skills),
        JSON.stringify(analysis.feedback)
      ]
    );

    res.json({ ...analysis, id: result.rows[0].id });
  } catch (error) {
    console.error('Error analyzing resume:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/resume/history', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, file_name, uploaded_at, personal_details, resume_content, skills, feedback FROM resumes ORDER BY uploaded_at DESC'
    );
    
    const resumes = result.rows.map(row => ({
      id: row.id,
      file_name: row.file_name,
      uploaded_at: row.uploaded_at,
      personal_details: row.personal_details,
      resume_content: row.resume_content,
      skills: row.skills,
      feedback: row.feedback
    }));

    res.json(resumes);
  } catch (error) {
    console.error('Error fetching resume history:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/resume/:id', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT file_name, uploaded_at, personal_details, resume_content, skills, feedback FROM resumes WHERE id = $1',
      [req.params.id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Resume not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching resume:', error);
    res.status(500).json({ error: error.message });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ 
    error: 'Something went wrong!',
    details: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
