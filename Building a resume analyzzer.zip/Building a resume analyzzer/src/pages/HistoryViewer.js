import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  Grid,
  Card,
  CardContent,
} from '@mui/material';

const HistoryViewer = () => {
  const [resumes, setResumes] = useState([]);
  const [selectedResume, setSelectedResume] = useState(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    fetchResumes();
  }, []);

  const fetchResumes = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/resume/history');
      if (!response.ok) throw new Error('Failed to fetch resumes');
      const data = await response.json();
      setResumes(data);
    } catch (error) {
      console.error('Error fetching resumes:', error);
    }
  };

  const handleDetailsClick = (resume) => {
    setSelectedResume(resume);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Paper sx={{ p: 3 }}>
          <Typography variant="h4" gutterBottom>
            Resume History
          </Typography>

          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Email</TableCell>
                  <TableCell>Rating</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {resumes.map((resume) => (
                  <TableRow key={resume.id}>
                    <TableCell>{resume.personalDetails.name}</TableCell>
                    <TableCell>{resume.personalDetails.email}</TableCell>
                    <TableCell>{resume.rating}/10</TableCell>
                    <TableCell>
                      <Button
                        variant="contained"
                        size="small"
                        onClick={() => handleDetailsClick(resume)}
                      >
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <Dialog
            open={open}
            onClose={handleClose}
            maxWidth="md"
            fullWidth
          >
            <DialogTitle>Resume Analysis Details</DialogTitle>
            <DialogContent>
              {selectedResume && (
                <Grid container spacing={3}>
                  <Grid item xs={12} md={6}>
                    <Card>
                      <CardContent>
                        <Typography variant="h6" gutterBottom>
                          Personal Details
                        </Typography>
                        <Typography>
                          Name: {selectedResume.personalDetails.name}
                        </Typography>
                        <Typography>
                          Email: {selectedResume.personalDetails.email}
                        </Typography>
                        <Typography>
                          Phone: {selectedResume.personalDetails.phone}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>

                  <Grid item xs={12} md={6}>
                    <Card>
                      <CardContent>
                        <Typography variant="h6" gutterBottom>
                          Rating & Feedback
                        </Typography>
                        <Typography>
                          Resume Score: {selectedResume.rating}/10
                        </Typography>
                        <Typography>
                          Improvement Areas:
                        </Typography>
                        <ul>
                          {selectedResume.feedback.improvementAreas.map((area, index) => (
                            <li key={index}>{area}</li>
                          ))}
                        </ul>
                        <Typography>
                          Suggested Skills:
                        </Typography>
                        <ul>
                          {selectedResume.feedback.suggestedSkills.map((skill, index) => (
                            <li key={index}>{skill}</li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>
              )}
            </DialogContent>
          </Dialog>
        </Paper>
      </Box>
    </Container>
  );
};

export default HistoryViewer;
