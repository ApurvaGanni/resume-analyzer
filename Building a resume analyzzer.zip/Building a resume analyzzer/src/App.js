import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { Container, Box, AppBar, Tabs, Tab, Toolbar, Typography } from '@mui/material';

import ResumeAnalysis from './pages/ResumeAnalysis';
import HistoryViewer from './pages/HistoryViewer';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

function App() {
  const [tabValue, setTabValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Box sx={{ flexGrow: 1 }}>
          <AppBar position="static">
            <Toolbar>
              <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                Resume Analyzer
              </Typography>
            </Toolbar>
            <Tabs value={tabValue} onChange={handleChange} centered>
              <Tab label="Resume Analysis" to="/" component="a" />
              <Tab label="History" to="/history" component="a" />
            </Tabs>
          </AppBar>
          <Container sx={{ mt: 4 }}>
            <Routes>
              <Route path="/" element={<ResumeAnalysis />} />
              <Route path="/history" element={<HistoryViewer />} />
            </Routes>
          </Container>
        </Box>
      </Router>
    </ThemeProvider>
  );
}

export default App;
